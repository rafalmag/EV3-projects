package lejos.remote.nxt;

import java.io.IOException;

public interface Connection {
	public void close() throws IOException;
}
