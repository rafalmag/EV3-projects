/**
 * Localization support
 */
package lejos.robotics.localization;
