/**
 * Modeling of wheeled vehicles
 */
package lejos.robotics.chassis;